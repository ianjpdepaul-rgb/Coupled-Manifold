"""
COUPLED MANIFOLD — Local Suite
Qwen2.5-3B-Instruct | MPS generation | MPS Hessian | Self-correcting SnobLine
Online learning | DuckDuckGo search | Conversation persistence | PWA-ready

pip install torch transformers accelerate gradio numpy duckduckgo-search fastapi uvicorn
python app.py
"""

import os, torch, torch.nn as nn
import numpy as np, json, time, gc
import gradio as gr
from transformers import AutoModelForCausalLM, AutoTokenizer
from fastapi import FastAPI
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
import uvicorn

# ═══════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════

MODEL     = "Qwen/Qwen2.5-3B-Instruct"
RANK      = 8
HUTCH_N   = 2
MAX_CTX   = 64
MAX_NEW   = 512
LR        = 1e-5
DATA_DIR  = "./manifold_data"
DEV       = torch.device("mps" if torch.backends.mps.is_available() else "cpu")

CONSEC_PATHO_LIMIT = 3
TREND_WINDOW       = 5
TREND_THRESHOLD    = -20

for d in ("sessions", "checkpoints", "logs", "static"):
    os.makedirs(f"{DATA_DIR}/{d}", exist_ok=True)

# Write PWA static files
os.makedirs("./static", exist_ok=True)

MANIFEST = {
    "name": "Coupled Manifold",
    "short_name": "Manifold",
    "description": "Local AI agent with real-time curvature monitoring",
    "start_url": "/",
    "display": "standalone",
    "background_color": "#0a0a0a",
    "theme_color": "#0a0a0a",
    "orientation": "portrait",
    "icons": [
        {"src": "/static/icon-192.png", "sizes": "192x192", "type": "image/png"},
        {"src": "/static/icon-512.png", "sizes": "512x512", "type": "image/png"},
        {"src": "/static/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"}
    ]
}
with open("./static/manifest.json", "w") as f:
    json.dump(MANIFEST, f, indent=2)

SW_JS = """
const CACHE = 'coupled-manifold-v1';
const ASSETS = ['/'];

self.addEventListener('install', e => {
    e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
    self.skipWaiting();
});

self.addEventListener('activate', e => {
    e.waitUntil(caches.keys().then(keys =>
        Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ));
    self.clients.claim();
});

self.addEventListener('fetch', e => {
    if (e.request.method !== 'GET') return;
    e.respondWith(
        fetch(e.request).catch(() =>
            caches.match(e.request).then(r => r || caches.match('/'))
        )
    );
});
"""
with open("./static/sw.js", "w") as f:
    f.write(SW_JS)

# Resize icon for PWA if icon.png exists
def make_pwa_icons():
    for src in ("./icon.png", "./slash_icon_v4.png", "./app_icon.png"):
        if os.path.exists(src):
            try:
                from PIL import Image
                img = Image.open(src).convert("RGBA")
                for size in (192, 512):
                    img.resize((size, size), Image.LANCZOS).save(f"./static/icon-{size}.png")
                print(f"  PWA icons created from {src}")
                return
            except ImportError:
                import shutil
                shutil.copy(src, "./static/icon-192.png")
                shutil.copy(src, "./static/icon-512.png")
                return
    print("  ⚠️  No icon.png found — PWA will use default icon")

make_pwa_icons()

print("=" * 50)
print("  COUPLED MANIFOLD — Local Suite")
print("=" * 50)
print(f"  Device: {DEV}")


# ═══════════════════════════════════════════════════
# DUAL ADAPTER
# ═══════════════════════════════════════════════════

class DualAdapter(nn.Module):
    def __init__(self, base, rank=RANK):
        super().__init__()
        self.base = base
        self.base.requires_grad_(False)
        inf, outf = base.in_features, base.out_features
        dev = next(base.parameters()).device
        dt  = next(base.parameters()).dtype
        self.lA = nn.Parameter(torch.randn(rank, inf,  device=dev, dtype=dt) * 0.01)
        self.lB = nn.Parameter(torch.zeros(outf, rank, device=dev, dtype=dt))
        self.aA = nn.Parameter(torch.randn(rank, inf,  device=dev, dtype=dt) * 0.01)
        self.aB = nn.Parameter(torch.zeros(outf, rank, device=dev, dtype=dt))
        self.scale, self.a_str = 2.0, 0.1
        self.lora_on, self.anti_on = True, False

    def forward(self, x):
        out = self.base(x)
        if self.lora_on:
            out = out + (x @ self.lA.T) @ self.lB.T * self.scale
        if self.anti_on:
            out = out + (x @ self.aA.T) @ self.aB.T * self.a_str
        return out


# ═══════════════════════════════════════════════════
# SNOBLINE
# ═══════════════════════════════════════════════════

class SnobLine:
    def __init__(self, window=10, low_pct=30, high_pct=50, max_anti=2):
        self.window, self.low_pct, self.high_pct = window, low_pct, high_pct
        self.max_anti   = max_anti
        self.mode       = "lora"
        self.history    = []
        self.all_traces = []
        self.anti_count = 0
        self.consec_patho = 0
        self.log        = []

    def step(self, trace, turn):
        self.all_traces.append(trace)
        if self.mode == "anti":
            self.anti_count += 1
            if self.anti_count >= self.max_anti:
                self.mode, self.anti_count = "lora", 0
                self.log.append({"turn": turn, "to": "lora", "reason": "max_duration"})
                return self.mode
        else:
            self.history.append(trace)
        if len(self.history) < 3:
            return self.mode
        recent = self.history[-self.window:]
        low  = float(np.percentile(recent, self.low_pct))
        high = float(np.percentile(recent, self.high_pct))
        if self.mode == "lora" and trace < low:
            self.mode, self.anti_count = "anti", 0
            self.consec_patho += 1
            self.log.append({"turn": turn, "to": "anti",
                             "trace": trace, "low": low, "high": high})
        elif self.mode == "anti" and trace > high:
            self.mode, self.anti_count = "lora", 0
            self.consec_patho = 0
            self.log.append({"turn": turn, "to": "lora", "reason": "recovered"})
        else:
            if self.mode == "lora":
                self.consec_patho = 0
        return self.mode

    def trend(self):
        if len(self.all_traces) < 3:
            return "building", 0, 0
        r = self.all_traces[-TREND_WINDOW:] if len(self.all_traces) >= TREND_WINDOW else self.all_traces
        slope = (r[-1] - r[0]) / len(r) if len(r) > 1 else 0
        avg   = np.mean(r)
        return ("declining" if slope < -10 else "rising" if slope > 10 else "stable"), avg, slope

    def should_terminate(self):
        if self.consec_patho >= CONSEC_PATHO_LIMIT:
            return True, "sustained_pathological"
        if len(self.all_traces) >= TREND_WINDOW:
            r = self.all_traces[-TREND_WINDOW:]
            if (r[-1] - r[0]) / len(r) < TREND_THRESHOLD:
                return True, "drift_detected"
        return False, None

    def get_thresholds(self):
        if len(self.history) < 3:
            return 0, 0
        recent = self.history[-self.window:]
        return float(np.percentile(recent, self.low_pct)), float(np.percentile(recent, self.high_pct))


# ═══════════════════════════════════════════════════
# HESSIAN TRACE
# ═══════════════════════════════════════════════════

def compute_trace(input_ids):
    model.eval()
    for n, p in model.named_parameters():
        if any(k in n for k in ("lA", "lB", "aA", "aB")):
            p.requires_grad = True
    params = [p for n, p in model.named_parameters()
              if p.requires_grad and ("lA" in n or "lB" in n)]
    if not params:
        model.train()
        return 0.0
    ids = input_ids[:, :MAX_CTX].to(DEV)
    try:
        with torch.enable_grad():
            out   = model(input_ids=ids, labels=ids)
            grads = torch.autograd.grad(out.loss, params, create_graph=True, allow_unused=True)
            grads = [g if g is not None else torch.zeros_like(p) for g, p in zip(grads, params)]
            estimates = []
            for _ in range(HUTCH_N):
                vs  = [torch.randint(0, 2, p.shape, device=p.device, dtype=p.dtype)*2-1 for p in params]
                gv  = sum((g*v).sum() for g, v in zip(grads, vs))
                hvp = torch.autograd.grad(gv, params, retain_graph=True, allow_unused=True)
                hvp = [h if h is not None else torch.zeros_like(p) for h, p in zip(hvp, params)]
                estimates.append(sum((v*h).sum().item() for v, h in zip(vs, hvp)))
        if DEV.type == "mps":
            torch.mps.empty_cache()
        model.train()
        return float(np.mean(estimates))
    except RuntimeError as e:
        print(f"  [trace failed: {e}]")
        if DEV.type == "mps":
            torch.mps.empty_cache()
        model.train()
        return 0.0


# ═══════════════════════════════════════════════════
# SEARCH
# ═══════════════════════════════════════════════════

def search_web(query):
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            return [{"title": r.get("title", ""), "body": r.get("body", "")}
                    for r in ddgs.text(query, max_results=3)]
    except:
        return []

def should_search(msg):
    if msg.startswith("/search "):
        return True
    triggers = ["what is", "who is", "when did", "where is", "how does",
                "latest", "news", "current", "today", "2024", "2025", "2026",
                "tell me about", "explain", "search", "look up", "find"]
    return any(t in msg.lower() for t in triggers)


# ═══════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════

def set_mode(mode):
    for mod in model.modules():
        if isinstance(mod, DualAdapter):
            mod.lora_on = mode in ("lora", "both")
            mod.anti_on = mode in ("anti", "both")

def strip_medulla(content):
    if isinstance(content, str) and "<div style=" in content:
        return content.split("\n\n<div style=")[0]
    if not isinstance(content, str):
        return str(content)
    return content

def extract_text(msg):
    """Safely extract plain string from any Gradio message format."""
    if isinstance(msg, str):
        return msg.strip()
    if isinstance(msg, dict):
        return str(msg.get("text", msg.get("content", str(msg)))).strip()
    return str(msg).strip()

def save_checkpoint(turn):
    weights = {n: p.data.cpu() for n, p in model.named_parameters() if p.requires_grad}
    torch.save(weights, f"{DATA_DIR}/checkpoints/ckpt_t{turn}.pt")
    with open(f"{DATA_DIR}/checkpoints/ckpt_t{turn}_snob.json", "w") as f:
        json.dump({"history": ctrl.history, "all_traces": ctrl.all_traces,
                   "log": ctrl.log, "mode": ctrl.mode}, f)
    print(f"  💾 Checkpoint saved: t{turn}")

def load_latest_checkpoint():
    pts = sorted([f for f in os.listdir(f"{DATA_DIR}/checkpoints") if f.endswith(".pt")])
    if not pts:
        return
    latest = pts[-1]
    print(f"  Resuming weights from {latest}")
    state = torch.load(f"{DATA_DIR}/checkpoints/{latest}",
                       weights_only=False, map_location="cpu")
    for n, p in model.named_parameters():
        if n in state:
            p.data.copy_(state[n].to(p.device))
    snob_path = f"{DATA_DIR}/checkpoints/{latest.replace('.pt', '_snob.json')}"
    if os.path.exists(snob_path):
        with open(snob_path) as f:
            s = json.load(f)
            ctrl.history    = s.get("history", [])
            ctrl.all_traces = s.get("all_traces", [])
            ctrl.log        = s.get("log", [])
            ctrl.mode       = s.get("mode", "lora")

def save_history(history):
    clean = []
    for h in history:
        if isinstance(h, dict):
            clean.append({"role": h.get("role", "user"),
                          "content": strip_medulla(h.get("content", ""))})
    with open(f"{DATA_DIR}/sessions/last_history.json", "w") as f:
        json.dump(clean[-20:], f)

def load_history():
    path = f"{DATA_DIR}/sessions/last_history.json"
    if os.path.exists(path):
        with open(path) as f:
            hist = json.load(f)
        print(f"  Conversation: {len(hist)} turns loaded")
        return hist
    return []


# ═══════════════════════════════════════════════════
# LOAD MODEL
# ═══════════════════════════════════════════════════

print(f"\n  Loading {MODEL}...")
tok = AutoTokenizer.from_pretrained(MODEL)
if tok.pad_token is None:
    tok.pad_token = tok.eos_token

model = AutoModelForCausalLM.from_pretrained(
    MODEL, torch_dtype=torch.bfloat16, attn_implementation="eager",
).to(DEV)
for p in model.parameters():
    p.requires_grad = False

count = 0
for name, mod in list(model.named_modules()):
    if name.split(".")[-1] in ("q_proj", "v_proj") and isinstance(mod, nn.Linear):
        parts = name.split(".")
        parent = model
        for p in parts[:-1]:
            parent = getattr(parent, p)
        setattr(parent, parts[-1], DualAdapter(mod))
        count += 1

for n, p in model.named_parameters():
    if any(k in n for k in ("lA", "lB", "aA", "aB")):
        p.requires_grad = True

trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
total     = sum(p.numel() for p in model.parameters())
print(f"  Adapters: {count} | Trainable: {trainable:,} / {total:,}")

opt          = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=LR)
ctrl         = SnobLine()
session_id   = int(time.time())
session_log  = []
turn_count   = [0]

load_latest_checkpoint()
startup_history = load_history()
print(f"  SnobLine: {len(ctrl.history)} trace entries | Mode: {ctrl.mode}")
print("  Ready.\n")


# ═══════════════════════════════════════════════════
# CHAT
# ═══════════════════════════════════════════════════

def chat(user_msg, history):
    # ── Fix: always extract plain string regardless of Gradio version ──
    user_msg = extract_text(user_msg)
    if not user_msg:
        return "", history or []

    if not history:
        history = list(startup_history) if startup_history else []

    turn_count[0] += 1
    t0 = time.time()
    searched = False

    # Search
    search_query = user_msg[8:] if user_msg.startswith("/search ") else user_msg
    context = ""
    if should_search(user_msg):
        results = search_web(search_query)
        if results:
            searched = True
            context  = "Recent information:\n"
            for r in results:
                context += f"- {r['title']}: {r['body']}\n"
            context += f"\nAnswer: {user_msg}"

    # Build messages
    history.append({"role": "user", "content": user_msg})
    recent   = history[-20:]
    messages = []
    for h in recent:
        role    = h.get("role", "user") if isinstance(h, dict) else "user"
        content = h.get("content", "") if isinstance(h, dict) else str(h)
        content = strip_medulla(content)
        if h == recent[-1] and context and role == "user":
            messages.append({"role": "user", "content": context})
        else:
            messages.append({"role": role, "content": content})

    prompt = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    ids    = tok(prompt, return_tensors="pt").input_ids.to(DEV)
    attn   = torch.ones_like(ids)

    # Generate
    with torch.no_grad():
        out_ids = model.generate(
            ids, attention_mask=attn, max_new_tokens=MAX_NEW, min_new_tokens=20,
            do_sample=True, temperature=0.7, top_p=0.95,
            pad_token_id=tok.eos_token_id,
        )
    response = tok.decode(out_ids[0][ids.shape[1]:], skip_special_tokens=True)
    if "</think>" in response:
        response = response.split("</think>")[-1].strip()
    gen_time = time.time() - t0

    # Trace
    t1         = time.time()
    trace      = compute_trace(out_ids)
    trace_time = time.time() - t1

    # Switch
    mode = ctrl.step(trace, turn_count[0])
    set_mode(mode)

    # Termination
    should_term, term_reason = ctrl.should_terminate()
    term_warning = ""
    if should_term:
        term_warning = (
            "\n\n⚠️ **SUSTAINED PATHOLOGICAL CONVERGENCE** — geometry locked."
            if term_reason == "sustained_pathological" else
            "\n\n⚠️ **CURVATURE DRIFT** — trace progressively declining."
        )

    # Online learning
    with torch.enable_grad():
        learn_ids = out_ids[:, :MAX_CTX].to(DEV)
        out       = model(input_ids=learn_ids, labels=learn_ids)
        out.loss.backward()
        torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
        opt.step()
        opt.zero_grad()
    model.zero_grad(set_to_none=True)
    if DEV.type == "mps":
        torch.mps.empty_cache()

    elapsed    = time.time() - t0
    trend_name, avg, slope = ctrl.trend()
    low_t, high_t = ctrl.get_thresholds()

    # Medulla
    icon  = "🟢" if mode == "lora" else "🔴"
    state = "CONSTRUCTIVE" if mode == "lora" else "ROUGHENING"
    bar   = "█" * min(max(int(abs(trace) / 100), 1), 30)
    ti    = "📉" if trend_name == "declining" else "📈" if trend_name == "rising" else "➡️"

    medulla = (
        f"\n\n<div style='margin-top:12px; border-left:3px solid "
        f'{"#4CAF50" if mode=="lora" else "#F44336"};'
        f" padding:8px 12px; font-family:monospace; font-size:0.78em;"
        f" background:rgba(0,0,0,0.03); border-radius:4px;'>"
        f"<b>{icon} MEDULLA</b> t{turn_count[0]} — "
        f"{gen_time:.1f}s gen / {trace_time:.1f}s trace / {elapsed:.1f}s total<br>"
        f"<b>STATE</b>: {state} | <b>TRACE</b>: {trace:.1f} <code>{bar}</code><br>"
        f"<b>TREND</b>: {ti} {trend_name} (avg {avg:.0f} | slope {slope:.0f})<br>"
        f"<b>THRESHOLDS</b>: low {low_t:.0f} / high {high_t:.0f} | "
        f"<b>SWITCHES</b>: {len(ctrl.log)}<br>"
        f"<b>SEARCH</b>: {'🌐' if searched else 'OFF'} | "
        f"<b>PATHO</b>: {ctrl.consec_patho}/{CONSEC_PATHO_LIMIT}"
        f"</div>"
    )

    # Log
    session_log.append({
        "turn": turn_count[0], "user": user_msg, "response": response,
        "trace": trace, "mode": mode, "searched": searched,
        "gen_time": round(gen_time, 1), "trace_time": round(trace_time, 1),
        "trend": trend_name, "slope": round(slope, 1),
        "terminated": should_term, "term_reason": term_reason,
    })
    with open(f"{DATA_DIR}/sessions/session_{session_id}.json", "w") as f:
        json.dump({"session_id": session_id, "model": MODEL,
                   "turns": session_log, "switches": ctrl.log}, f, indent=2)
    with open(f"{DATA_DIR}/logs/traces.jsonl", "a") as f:
        f.write(json.dumps({
            "session": session_id, "turn": turn_count[0],
            "trace": trace, "mode": mode, "trend": trend_name,
            "slope": round(slope, 1), "time": time.time()
        }) + "\n")

    if turn_count[0] % 25 == 0:
        save_checkpoint(turn_count[0])

    save_history(history)
    term_flag = f" | ⚠️ {term_reason}" if should_term else ""
    print(f"  t{turn_count[0]} | trace {trace:.0f} | {mode} | {trend_name} | "
          f"gen {gen_time:.1f}s | hess {trace_time:.1f}s"
          + (" | 🌐" if searched else "") + term_flag)

    history.append({"role": "assistant", "content": response + term_warning + medulla})
    return "", history


# ═══════════════════════════════════════════════════
# PWA HEAD JS — injects manifest + service worker
# ═══════════════════════════════════════════════════

PWA_JS = """
() => {
    // Manifest link
    if (!document.querySelector('link[rel="manifest"]')) {
        const l = document.createElement('link');
        l.rel = 'manifest'; l.href = '/static/manifest.json';
        document.head.appendChild(l);
    }
    // Theme color
    if (!document.querySelector('meta[name="theme-color"]')) {
        const m = document.createElement('meta');
        m.name = 'theme-color'; m.content = '#0a0a0a';
        document.head.appendChild(m);
    }
    // Apple PWA tags
    const appleTags = [
        ['apple-mobile-web-app-capable', 'yes'],
        ['apple-mobile-web-app-status-bar-style', 'black-translucent'],
        ['apple-mobile-web-app-title', 'Manifold'],
    ];
    appleTags.forEach(([name, content]) => {
        if (!document.querySelector(`meta[name="${name}"]`)) {
            const m = document.createElement('meta');
            m.name = name; m.content = content;
            document.head.appendChild(m);
        }
    });
    // Service worker
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/static/sw.js').catch(() => {});
    }
}
"""


# ═══════════════════════════════════════════════════
# GRADIO UI
# ═══════════════════════════════════════════════════

with gr.Blocks(
    title="Coupled Manifold",
    js=PWA_JS,
    css="""
        body { background: #0a0a0a !important; }
        .gradio-container { max-width: 800px !important; margin: 0 auto; }
        #component-0 { background: #0a0a0a; }
        footer { display: none !important; }
    """
) as gradio_app:

    gr.Markdown(
        "# 🧠 coupled manifold\n"
        "`Qwen 3B` · `Hessian trace` · `self-correcting` · `online learning` "
        "· `web search` · `dual termination`\n\n"
        "*Prefix `/search` to force web search. Geometry monitored in real time.*"
    )

    chatbot = gr.Chatbot(
        height=560,
        show_label=False,
        type="messages",                          # ← fixes the JSON bug
        value=startup_history if startup_history else [],
    )

    with gr.Row():
        msg        = gr.Textbox(
            placeholder="say something...",
            show_label=False,
            container=False,
            scale=8,
        )
        search_btn = gr.Button("🌐", scale=1, min_width=50)
        clear      = gr.Button("🗑️", scale=1, min_width=50)

    msg.submit(chat, [msg, chatbot], [msg, chatbot])
    search_btn.click(
        lambda m, h: chat(f"/search {m}", h),
        [msg, chatbot], [msg, chatbot]
    )
    clear.click(lambda: ("", []), None, [msg, chatbot])


# ═══════════════════════════════════════════════════
# FASTAPI WRAPPER — serves PWA static files + Gradio
# ═══════════════════════════════════════════════════

api = FastAPI()
api.mount("/static", StaticFiles(directory="./static"), name="static")

@api.get("/static/sw.js", include_in_schema=False)
async def service_worker():
    return FileResponse("./static/sw.js",
                        media_type="application/javascript",
                        headers={"Service-Worker-Allowed": "/"})

app = gr.mount_gradio_app(api, gradio_app, path="/")

if __name__ == "__main__":
    print("  http://localhost:7860")
    print("  Share on phone: open that URL on your phone (same WiFi)")
    print("  On phone: tap Share → Add to Home Screen to install as app\n")
    uvicorn.run(app, host="0.0.0.0", port=7860)
