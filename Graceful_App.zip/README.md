# Coupled Manifold

A local AI agent that monitors its own optimization geometry in real time.

---

## What it is

Coupled Manifold runs a small language model (Qwen 3B) on your machine and measures the curvature of its own loss landscape — the Hessian trace — as it processes your prompts. When the curvature collapses, the model is locking onto a pathological attractor: a hallucination groove, a demographic shortcut, or an adversarial pattern. The system detects this geometrically, without needing to know what the content is.

The session terminates when the curvature stays flat for too long. Not because the content was flagged. Because the geometry went wrong.

This is not a chatbot. It is a coupled system — you are the somatic half, the model is the computational half, and the Hessian trace is what happens between you.

---

## Requirements

- Mac (Apple Silicon or Intel)
- Python 3.9 or later — get it at [python.org](https://python.org)
- ~8GB free disk space (model download, one-time)
- A free [Hugging Face](https://huggingface.co) account

---

## Setup

Double Click 'Graceful'.

That's it. The script will:

1. Check your Python installation
2. Create an isolated virtual environment
3. Install all dependencies
4. Prompt you for a HuggingFace token (free, takes 30 seconds to get)
5. Download the model (~6GB, one-time only)
6. Build `Graceful.app` with the correct icon
7. Ask if you want to launch immediately

Every launch after setup: double-click `Graceful.app`.

---

## Files in this folder

| File | Purpose |
|---|---|
| `app.py` | The application |
| `setup.sh` | Run once to set everything up |
| `icon.png` | App icon |
| `Graceful.app` | Created by setup.sh — your launcher |

---

## What the interface shows

- **Chat** — your input, the model's response
- **Trace** — the Hessian curvature value for that turn. Higher = more exploratory, lower = more locked. Positive is healthy. Near-zero or negative means the model is converging on a narrow attractor.
- **Mode** — `lora` (constructive) or `anti` (roughening). Switches automatically based on the rolling curvature window.
- **Session terminated** — appears when the model has been in pathological convergence long enough that the session is no longer productive. Start a new one.

---

## Data

Everything saves to `manifold_data/` in the same folder as `app.py`:

- `sessions/` — full conversation logs with trace values per turn
- `checkpoints/` — adapter weights and SnobLine state
- `logs/` — continuous trace history

Sessions persist across restarts. Your conversation history, curvature history, and SnobLine rolling window all reload when you open the app again.

---

## HuggingFace Token

The model (Qwen/Qwen2.5-3B-Instruct) requires a free HuggingFace account. During setup you'll be prompted for a token. To get one:

1. Go to [huggingface.co/settings/tokens](https://huggingface.co/settings/tokens)
2. Click **New token**
3. Name it anything, set access to **Read**
4. Copy and paste it when setup.sh asks

The token is stored locally by the HuggingFace library. You won't need to enter it again.

---

## Troubleshooting

**"Python 3 not found"** — Install from [python.org](https://python.org) and re-run setup.sh.

**Model download fails** — Make sure you entered your HuggingFace token and accepted the model license at [huggingface.co/Qwen/Qwen2.5-3B-Instruct](https://huggingface.co/Qwen/Qwen2.5-3B-Instruct).

**App won't open / "app is damaged"** — macOS quarantine. Run in Terminal: `xattr -cr Graceful.app`

**Slow responses** — Normal on CPU. Apple Silicon (M1/M2/M3/M4) runs significantly faster via MPS. Intel Macs will be slower but functional.

**Session keeps terminating** — The curvature monitor is sensitive to sustained adversarial input. Try a fresh session with a different opening prompt.

---

## Research context

This application is a deployment of the Coupled Manifold Safety Framework. The theoretical foundation, experimental results, and full paper are available at:

[ResearchGate — Ian J. Preston-Campbell](https://www.researchgate.net/profile/Ian-Preston-Campbell)

[Substack — ijpc43.substack.com](https://ijpc43.substack.com)

---

*CC BY 4.0 — Ian J. Preston-Campbell, 2026*
