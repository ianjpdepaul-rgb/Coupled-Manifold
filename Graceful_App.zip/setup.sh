#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  COUPLED MANIFOLD — Universal Setup
#  Run once: bash setup.sh
#  Every launch after: double-click Graceful.app
# ═══════════════════════════════════════════════════════════════

set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  COUPLED MANIFOLD — Setup"
echo "═══════════════════════════════════════════════════════════"
echo ""

# ── 1. Python check ─────────────────────────────────────────────
if ! command -v python3 &> /dev/null; then
    echo "❌  Python 3 not found."
    echo "    Install from https://python.org then re-run this script."
    read -p "    Press Enter to exit." _
    exit 1
fi
PY=$(python3 --version)
echo "✅  $PY found."

# ── 2. Virtual environment ───────────────────────────────────────
if [ ! -d "$DIR/graceful_env" ]; then
    echo ""
    echo "📦  Creating virtual environment..."
    python3 -m venv "$DIR/graceful_env"
    echo "✅  Environment created."
else
    echo "✅  Virtual environment already exists."
fi

source "$DIR/graceful_env/bin/activate"

# ── 3. Dependencies ──────────────────────────────────────────────
echo ""
echo "📦  Installing dependencies (first time may take a few minutes)..."
pip install --upgrade pip -q
pip install torch transformers accelerate gradio numpy \
    duckduckgo-search huggingface_hub fastapi uvicorn pillow -q
echo "✅  Dependencies installed."

# ── 4. Hugging Face token ────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  Hugging Face Token"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "  The model needs a free HuggingFace token to download."
echo "  Get one at: https://huggingface.co/settings/tokens"
echo "  (New token → Read access → copy and paste below)"
echo ""
read -p "  Paste your HF token (or Enter to skip): " HF_TOKEN

if [ ! -z "$HF_TOKEN" ]; then
    python3 -c "from huggingface_hub import login; login(token='$HF_TOKEN')"
    echo "✅  Token saved."
else
    echo "⚠️   Skipped — model may fail to download if gated."
fi

# ── 5. Pick model size ───────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  Choose Model Size"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "  1)  1.5B — for 8GB RAM   (~3GB download, faster)"
echo "  2)  3B   — for 16GB RAM  (~6GB download, smarter)"
echo ""
read -p "  Enter 1 or 2 [default: 2]: " MODEL_CHOICE

if [ "$MODEL_CHOICE" = "1" ]; then
    SELECTED_MODEL="Qwen/Qwen2.5-1.5B-Instruct"
    echo "✅  Using 1.5B model."
else
    SELECTED_MODEL="Qwen/Qwen2.5-3B-Instruct"
    echo "✅  Using 3B model."
fi

# Write model choice into app.py
sed -i '' "s|MODEL = \"Qwen/Qwen2.5-.*-Instruct\"|MODEL = \"$SELECTED_MODEL\"|" "$DIR/app.py" 2>/dev/null || \
python3 -c "
import re, sys
path = '$DIR/app.py'
txt = open(path).read()
txt = re.sub(r'MODEL = \"Qwen/Qwen2\.5-[^\"]+\"', 'MODEL = \"$SELECTED_MODEL\"', txt)
open(path,'w').write(txt)
print('✅  Model selection saved to app.py.')
"

# ── 6. Download model ────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  Downloading Model (one-time only)"
echo "═══════════════════════════════════════════════════════════"
echo ""
python3 -c "
from transformers import AutoModelForCausalLM, AutoTokenizer
m = '$SELECTED_MODEL'
print('  Downloading tokenizer...')
AutoTokenizer.from_pretrained(m)
print('  Downloading model weights (a few minutes)...')
AutoModelForCausalLM.from_pretrained(m)
print('  Model cached.')
"

# ── 7. Build Graceful.app ────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  Building Graceful.app"
echo "═══════════════════════════════════════════════════════════"
echo ""

APP="$DIR/Graceful.app"
MACOS="$APP/Contents/MacOS"
RES="$APP/Contents/Resources"
mkdir -p "$MACOS" "$RES"

# Quoted heredoc — $DIR and $0 resolve at runtime, not setup time
cat << 'LAUNCHER' > "$MACOS/Graceful"
#!/bin/bash
DIR="$(cd "$(dirname "$0")/../../.." && pwd)"
cd "$DIR"
if [ ! -d "$DIR/graceful_env" ]; then
    osascript -e 'tell app "Terminal" to do script "cd \"'"$DIR"'\" && bash setup.sh"'
    osascript -e 'tell app "Terminal" to activate'
else
    source "$DIR/graceful_env/bin/activate"
    python3 "$DIR/app.py"
fi
LAUNCHER
chmod +x "$MACOS/Graceful"

cat << 'PLIST' > "$APP/Contents/Info.plist"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key>
    <string>Coupled Manifold</string>
    <key>CFBundleDisplayName</key>
    <string>Coupled Manifold</string>
    <key>CFBundleIdentifier</key>
    <string>com.coupledmanifold.graceful</string>
    <key>CFBundleVersion</key>
    <string>1.0</string>
    <key>CFBundleExecutable</key>
    <string>Graceful</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleIconFile</key>
    <string>AppIcon</string>
</dict>
</plist>
PLIST

echo "✅  Graceful.app built."

# ── 8. Icon → .icns ─────────────────────────────────────────────
ICON_SRC=""
for candidate in "$DIR/icon.png" "$DIR/slash_icon_v4.png" "$DIR/app_icon.png"; do
    if [ -f "$candidate" ]; then
        ICON_SRC="$candidate"
        break
    fi
done

if [ ! -z "$ICON_SRC" ] && command -v sips &> /dev/null && command -v iconutil &> /dev/null; then
    echo "  Converting icon: $(basename $ICON_SRC)"
    ICONSET="$DIR/icon.iconset"
    mkdir -p "$ICONSET"
    sips -z 16   16   "$ICON_SRC" --out "$ICONSET/icon_16x16.png"       -q
    sips -z 32   32   "$ICON_SRC" --out "$ICONSET/icon_16x16@2x.png"    -q
    sips -z 32   32   "$ICON_SRC" --out "$ICONSET/icon_32x32.png"       -q
    sips -z 64   64   "$ICON_SRC" --out "$ICONSET/icon_32x32@2x.png"    -q
    sips -z 128  128  "$ICON_SRC" --out "$ICONSET/icon_128x128.png"     -q
    sips -z 256  256  "$ICON_SRC" --out "$ICONSET/icon_128x128@2x.png"  -q
    sips -z 256  256  "$ICON_SRC" --out "$ICONSET/icon_256x256.png"     -q
    sips -z 512  512  "$ICON_SRC" --out "$ICONSET/icon_256x256@2x.png"  -q
    sips -z 512  512  "$ICON_SRC" --out "$ICONSET/icon_512x512.png"     -q
    sips -z 1024 1024 "$ICON_SRC" --out "$ICONSET/icon_512x512@2x.png"  -q
    iconutil -c icns "$ICONSET" -o "$RES/AppIcon.icns"
    rm -rf "$ICONSET"
    echo "✅  Icon set."
else
    echo "⚠️   No icon found — using default macOS icon."
    echo "    Rename your PNG to icon.png and re-run to set it."
fi

# ── 9. Clear quarantine ──────────────────────────────────────────
xattr -cr "$APP" 2>/dev/null || true
echo "✅  Quarantine cleared."

# ── Done ─────────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  ✅  Setup Complete!"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "  Launch:  double-click Graceful.app"
echo "  Or:      source graceful_env/bin/activate && python3 app.py"
echo "  Data:    $DIR/manifold_data/"
echo ""
read -p "  Launch now? (y/n): " LAUNCH
if [[ "$LAUNCH" =~ ^[Yy]$ ]]; then
    source "$DIR/graceful_env/bin/activate"
    python3 "$DIR/app.py"
fi
